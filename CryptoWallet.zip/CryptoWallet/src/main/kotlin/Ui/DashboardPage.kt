package Ui

import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.rememberScrollableState
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import firstcolor
import lightviloet
import myred
import secondcolor


@Composable
fun DashboardPage() {
    val scrollState = rememberScrollState()

    Row(modifier = Modifier.fillMaxSize()) {

        Column(modifier = Modifier.fillMaxSize().weight(2f)) {
            Text(
                "Dashboard",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(10.dp),
                fontSize = 25.sp,
                fontFamily = FontFamily.Monospace
            )
            //CryptoCard("bitcoin.png","BTC","Bitcoin","$29,930.11","-14.25","15.8")
            val list = remember { mutableListOf<CryptoCard>() }
            list.add(CryptoCard("bitcoin.png", "BTC", "Bitcoin", "$29,930.11", "-14.25", "15.8"))
            list.add(CryptoCard("binance.png", "BNB", "Binance Coin", "$42.16", "23.25", "60.8"))
            list.add(CryptoCard("ethereum.png", "ETH", "Ethereum", "$12,120.16", "10.25", "3.50"))
            list.add(CryptoCard("shiba.png", "SHIB", "Shiba", "$0.00.176", "-12.55", "100.10"))
            list.add(CryptoCard("bitcoin.png", "BTC", "Bitcoin", "$29,930.11", "-14.25", "15.8"))
            list.add(CryptoCard("binance.png", "BNB", "Binance Coin", "$42.16", "23.25", "60.8"))
            list.add(CryptoCard("ethereum.png", "ETH", "Ethereum", "$12,120.16", "10.25", "3.50"))
            list.add(CryptoCard("shiba.png", "SHIB", "Shiba", "$0.00.176", "-12.55", "100.10"))
            val scrollState = rememberScrollState()

                LazyColumn() {
                    itemsIndexed(items = list) { index, item ->
                        CryptoCardView(item)
                    }
                }
        }

     Box{

     }
    }
}



//@Composable
//fun HorizontalLazyStateExample(
//    modifier: Modifier,
//) {
//    Column(
//        modifier = modifier
//            .fillMaxWidth()
//            .padding(16.dp),
//        horizontalAlignment = Alignment.CenterHorizontally,
//        verticalArrangement = Arrangement.Center
//    ) {
//        Text(text = "Using Lazy List State", style = MaterialTheme.typography.h5)
//        val scrollState = rememberLazyListState()
//        LazyRow(
//            state = scrollState,
//        ) {
//            repeat(20) {
//                item {
//                    Box(
//                        modifier = Modifier.size(100.dp),
//                        contentAlignment = Alignment.Center
//                    ) {
//                        Text(text = "Item $it")
//                    }
//                }
//            }
//        }
//        Row(verticalAlignment = Alignment.CenterVertically) {
//            Text(text = "←←←")
//            Box(
//                modifier = Modifier.weight(1f),
//                contentAlignment = Alignment.Center
//            ) {
//                Carousel(state = scrollState)
//            }
//            Text(text = "→→→")
//        }
//    }
//}
@Composable
fun CryptoCardView(cryptoCard: CryptoCard){
Card(shape = RoundedCornerShape(10.dp),backgroundColor = secondcolor,modifier = Modifier.width(300.dp).height(200.dp).padding(10.dp).clickable {  },border = BorderStroke(1.dp,color = myred)) {
   Column (modifier = Modifier.fillMaxSize()) {
       Row(modifier = Modifier.fillMaxWidth().padding(10.dp),verticalAlignment = Alignment.CenterVertically,horizontalArrangement = Arrangement.Start) {
         Image(painter = painterResource(cryptoCard.name!!),"",modifier = Modifier.size(40.dp))
           Column(Modifier.weight(2f).padding(5.dp)) {
               Text(cryptoCard.coinsymbol!!,color = Color.White,fontFamily = FontFamily.Monospace,fontWeight = FontWeight.ExtraBold,fontSize = 18.sp)
               Text(cryptoCard.coinname!!,color = Color.LightGray,fontSize = 12.sp,fontFamily = FontFamily.Monospace)
           }
           if (cryptoCard.change!!.startsWith("-")){
               Icon(Icons.Outlined.KeyboardArrowDown,"",tint = Color.Red)
               Text(cryptoCard.change!! + "%",color = Color.Red)
           }else{
               Icon(Icons.Outlined.KeyboardArrowUp,"",tint = Color.Green)
               Text(cryptoCard.change!! + "%",color = Color.Green)
           }
       }

       Spacer(Modifier.size(15.dp))

       Text("Today Price",color = Color.LightGray,fontSize = 12.sp,fontFamily = FontFamily.Monospace,modifier = Modifier.padding(start = 20.dp))
       Spacer(Modifier.size(5.dp))
       Text("${cryptoCard.todayprice!!}",color = Color.White,fontSize = 18.sp,fontFamily = FontFamily.Monospace,fontWeight = FontWeight.Bold,modifier = Modifier.padding(start = 20.dp))

       Spacer(Modifier.size(15.dp))


       Text("Your Wallet",color = Color.LightGray,fontSize = 12.sp,fontFamily = FontFamily.Monospace,modifier = Modifier.padding(start = 20.dp))
       Spacer(Modifier.size(5.dp))
       Text("${cryptoCard.walletbalance!!} ${cryptoCard.coinsymbol!!}",color = Color.White,fontSize = 18.sp,fontFamily = FontFamily.Monospace,fontWeight = FontWeight.Bold,modifier = Modifier.padding(start = 20.dp))

   }
}
}
data class CryptoCard(var name:String?=null,var coinsymbol:String?= null,var coinname:String?=null,var todayprice:String?=null,var change:String?=null,var walletbalance:String?=null)

