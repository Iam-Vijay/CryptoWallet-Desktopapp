import Ui.HomePage
import androidx.compose.material.Text
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.WindowSize
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application

fun main() = application {

    androidx.compose.ui.window.Window(
        onCloseRequest = ::exitApplication,
        state = WindowState(size = WindowSize(1500.dp, 1000.dp))
    ) {
        MaterialTheme {
            HomePage()
        }
    }
}